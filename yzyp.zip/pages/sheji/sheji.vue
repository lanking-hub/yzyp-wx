<template>
	<view class="page-container">
		<!-- 自定义导航栏 -->
		<CustomNavBar />

		<!-- 内容区域，为导航栏留出空间 -->
		<view class="content-wrapper">
			<!-- 服装设计标题栏 -->
			<view class="section-header">
				<view class="title-left">
					<image class="title-icon" src="/static/icons/actions/pencil_active.svg" mode="aspectFit"></image>
					<text class="header-text">服装设计</text>
				</view>
				<view class="title-right" @click="refreshPage">
					<image class="refresh-icon" src="/static/icons/actions/刷新.svg" mode="aspectFit"></image>
				</view>
			</view>

			<!-- 设计描述容器 -->
			<view class="design-container">
				<view class="container-title gradient-1">
					<image class="title-icon" src="/static/icons/actions/tshirt.svg" mode="aspectFit"></image>
					<text class="title-text">设计描述</text>
				</view>
				<view class="container-content">
					<text class="brand-hint">描述您想要的服装</text>
					<textarea v-model="designDescription" class="desc-input" placeholder="例如：一条收腰纯色连衣裙，适合春季穿着…"
						placeholder-class="placeholder-text" />

					<!-- 品牌风格选择 -->
					<view class="brand-section">
						<text class="brand-hint">选择品牌风格</text>
						<view class="brand-list">
							<view class="brand-item" :class="{ active: selectedBrand === 'ralph-lauren' }"
								@click="selectBrand('ralph-lauren')">
								<image class="item-icon" src="/static/icons/brands/crown.svg" mode="aspectFit"></image>
								<text class="item-name">拉夫劳伦</text>
							</view>
							<view class="brand-item" :class="{ active: selectedBrand === 'house-of-cb' }"
								@click="selectBrand('house-of-cb')">
								<image class="item-icon" src="/static/icons/brands/woman.svg" mode="aspectFit"></image>
								<text class="item-name">House of CB</text>
							</view>
							<view class="brand-item" :class="{ active: selectedBrand === 'lululemon' }"
								@click="selectBrand('lululemon')">
								<image class="item-icon" src="/static/icons/brands/running.svg" mode="aspectFit">
								</image>
								<text class="item-name">Lululemon 与 Alo</text>
							</view>
							<view class="brand-item" :class="{ active: selectedBrand === 'zara' }"
								@click="selectBrand('zara')">
								<image class="item-icon" src="/static/icons/brands/bag.svg" mode="aspectFit"></image>
								<text class="item-name">ZARA</text>
							</view>
							<view class="brand-item" :class="{ active: selectedBrand === 'cos' }"
								@click="selectBrand('cos')">
								<image class="item-icon" src="/static/icons/brands/259钻石.svg" mode="aspectFit"></image>
								<text class="item-name">COS</text>
							</view>
						</view>
					</view>
				</view>
			</view>

			<!-- 生成按钮 -->
			<button class="generate-btn" @click="generateDesign" :disabled="isGenerating">
				<image v-if="!isGenerating" class="btn-icon-img" src="/static/icons/actions/wand-magic.svg"
					mode="aspectFit"></image>
				<text v-else class="btn-icon-emoji">⏳</text>
				<text class="btn-text">{{ isGenerating ? '生成中...' : '生成服装设计' }}</text>
			</button>

			<!-- 生成结果容器 -->
			<view class="design-container">
				<view class="container-title gradient-2">
					<image class="title-icon" src="/static/icons/actions/图片.svg" mode="aspectFit"></image>
					<text class="title-text">生成结果</text>
				</view>
				<view class="container-content">
					<!-- AI生成提示 -->
					<view class="ai-notice" v-if="generatedResult">
						<view class="ai-notice-content">
							<image class="ai-notice-icon" src="/static/icons/actions/提示.svg" mode="aspectFit"></image>
							<text class="ai-notice-text">图像由AI生成，请注意甄别</text>
						</view>
					</view>

					<!-- 显示生成的图片 -->
					<view v-if="generatedResult" class="result-image-container">
						<image class="result-image" :src="generatedResult" mode="aspectFit" @click="previewImage">
						</image>
						<view class="result-actions">
							<button class="action-btn save-btn" @click="saveImage">
								<image class="action-icon" src="/static/icons/actions/download.svg" mode="aspectFit">
								</image>
								<text class="action-text">保存图片</text>
							</button>
							<button class="action-btn retry-btn" @click="retryGenerate">
								<image class="action-icon" src="/static/icons/actions/pencil_active.svg"
									mode="aspectFit"></image>
								<text class="action-text">重新生成</text>
							</button>
						</view>
						<button class="collect-btn" @click="collectDesign" :disabled="isCollecting || !generatedHistoryId">
							<image v-if="!isCollecting" class="collect-icon-img" src="/static/icons/actions/爱心_active.svg"
								mode="aspectFit"></image>
							<text v-else class="collect-icon-emoji">⏳</text>
							<text class="collect-text">{{
								isCollecting ? '收藏中...' :
								!generatedHistoryId ? '无法收藏' :
								'收藏设计'
							}}</text>
						</button>
						<!-- 提示文字 -->
						<view class="warning-text">
							<text v-if="!generatedHistoryId" class="error-hint">⚠️ 记录保存失败，无法收藏。请使用"保存图片"功能。</text>
							<text v-else>生成图像有效期为30天，请及时保存</text>
						</view>
					</view>

					<!-- 生成签占位符 -->
					<view v-else class="result-placeholder">
						<view class="placeholder-image">
							<view class="clothing-icon">
								<image src="/static/icons/actions/tshirt.svg" mode="aspectFit"></image>
							</view>
							<text class="placeholder-text">生成的服装设计将显示在这里</text>
							<!-- 银色光影扫描效果 -->
							<view class="shimmer-effect"></view>
						</view>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import CustomNavBar from '../../components/CustomNavBar/CustomNavBar.vue'
	import {
		post
	} from '../../utils/request.js'

	export default {
		name: 'Sheji',
		components: {
			CustomNavBar
		},
		data() {
			return {
				designDescription: '',
				selectedBrand: 'ralph-lauren',
				generatedResult: null,
				generatedHistoryId: null, // 保存historyId
				isGenerating: false,
				isCollecting: false, // 新增：收藏状态
				selectingBrand: false, // 防止快速点击
				isSavingRecord: false, // 新增：正在保存记录状态
				recordSaveTimer: null, // 记录保存定时器
				// 品牌名称到缩写的映射
				brandMapping: {
					'ralph-lauren': 'rl',
					'house-of-cb': 'hoc',
					'lululemon': 'lulu',
					'zara': 'zara',
					'cos': 'cos'
				}
			}
		},
		methods: {
			// 选择品牌
			selectBrand(brand) {
				// 防止快速点击
				if (this.selectingBrand) {
					return
				}

				this.selectingBrand = true
				this.selectedBrand = brand
				console.log('选择品牌:', brand)

				// 使用 nextTick 确保 DOM 更新完成后再解除锁定
				this.$nextTick(() => {
					setTimeout(() => {
						this.selectingBrand = false
					}, 200) // 200ms 后允许再次点击
				})
			},

			// 生成设计
			async generateDesign() {
				// 验证输入
				if (!this.designDescription.trim()) {
					uni.showToast({
						title: '请输入设计描述',
						icon: 'none'
					})
					return
				}

				this.isGenerating = true

				try {
					// 获取品牌缩写
					const brandAbbr = this.brandMapping[this.selectedBrand]

					// 发送POST请求
					const result = await post('https://fashionai.top/image/generate', {
						prompt: this.designDescription,
						brand: brandAbbr,
						height: 1024, // 可以设置默认高度
						width: 1024 // 可以设置默认宽度
					})

					console.log('生成结果:', result)

					// 检查Result的code字段，成功是"0"
					if (result && result.code === "0" && result.data && result.data.imageUrl) {
						this.generatedResult = result.data.imageUrl
						this.generatedHistoryId = result.data.historyId // 保存historyId

						console.log('图片生成成功，完整响应数据:', result.data)
						console.log('图片生成成功，historyId:', this.generatedHistoryId)
						console.log('historyId 类型:', typeof this.generatedHistoryId)
						console.log('请求ID:', result.requestId)

						// 检查 historyId 是否有效
						if (!this.generatedHistoryId) {
							console.warn('警告：historyId 为空，可能无法收藏')
							uni.showModal({
								title: '生成成功但无法收藏',
								content: '图像已成功生成，但由于记录保存失败，无法收藏到收藏夹。请尽快保存图片到本地。',
								showCancel: false
							})
						} else {
							// 显示记录保存中提示
							this.isSavingRecord = true
							uni.showToast({
								title: '生成成功，正在保存记录...',
								icon: 'loading',
								duration: 2000
							})

							// 2秒后允许操作，给后端足够时间保存记录
							this.recordSaveTimer = setTimeout(() => {
								this.isSavingRecord = false
								console.log('记录保存完成，可以正常操作')
								uni.showToast({
									title: '记录保存完成',
									icon: 'success',
									duration: 1500
								})
							}, 2000)
						}
					} else if (result && result.code === "C000101") {
						// 特殊处理：图像生成成功但保存失败的情况
						uni.showModal({
							title: '部分成功',
							content: '图像已生成成功，但保存记录失败。是否仍要显示生成的图像？',
							success: (res) => {
								if (res.confirm) {
									// 用户选择显示图像，这里需要从其他地方获取图像URL
									// 或者让后端在错误响应中仍返回图像URL
									uni.showToast({
										title: '请联系开发者获取图像',
										icon: 'none'
									})
								}
							}
						})
					} else {
						throw new Error('生成结果格式异常: ' + (result ? result.message : '响应为空'))
					}

				} catch (error) {
					console.error('生成失败:', error)
					uni.showToast({
						title: '生成失败: ' + (error.message || '请重试'),
						icon: 'error'
					})
				} finally {
					this.isGenerating = false
				}
			},

			// 预览图片
			previewImage() {
				if (!this.generatedResult) return

				uni.previewImage({
					urls: [this.generatedResult],
					current: this.generatedResult
				})
			},

			// 保存图片
			saveImage() {
				if (!this.generatedResult) return

				// 检查是否正在保存记录
				if (this.isSavingRecord) {
					uni.showToast({
						title: '正在保存记录,请稍候...',
						icon: 'none',
						duration: 2000
					})
					return
				}

				// #ifdef MP-WEIXIN
				// ========== 微信小程序保存图片到相册 ==========
				uni.showLoading({
					title: '保存中...'
				})

				// 下载图片到本地
				uni.downloadFile({
					url: this.generatedResult,
					success: (res) => {
						if (res.statusCode === 200) {
							// 保存到相册
							uni.saveImageToPhotosAlbum({
								filePath: res.tempFilePath,
								success: () => {
									uni.hideLoading()
									uni.showToast({
										title: '保存成功',
										icon: 'success'
									})
								},
								fail: (err) => {
									uni.hideLoading()
									console.error('保存到相册失败:', err)

									// 检查是否是权限问题
									if (err.errMsg.includes('auth')) {
										uni.showModal({
											title: '需要授权',
											content: '保存图片需要授权访问相册',
											success: (modalRes) => {
												if (modalRes.confirm) {
													uni.openSetting()
												}
											}
										})
									} else {
										uni.showToast({
											title: '保存失败',
											icon: 'error'
										})
									}
								}
							})
						} else {
							uni.hideLoading()
							uni.showToast({
								title: '下载失败',
								icon: 'error'
							})
						}
					},
					fail: (err) => {
						uni.hideLoading()
						console.error('下载图片失败:', err)
						uni.showToast({
							title: '下载失败',
							icon: 'error'
						})
					}
				})
				// #endif

				// #ifdef H5
				// ========== H5网页下载图片 ==========
				uni.showLoading({
					title: '下载中...'
				})

				try {
					// 创建下载链接
					const link = document.createElement('a')
					link.href = this.generatedResult
					link.download = 'AI服装设计-' + Date.now() + '.png'
					link.target = '_blank'

					// 触发下载
					document.body.appendChild(link)
					link.click()
					document.body.removeChild(link)

					uni.hideLoading()
					uni.showToast({
						title: '下载已开始',
						icon: 'success'
					})
				} catch (error) {
					uni.hideLoading()
					console.error('H5下载图片失败:', error)
					uni.showToast({
						title: '下载失败，请尝试长按图片保存',
						icon: 'none'
					})
				}
				// #endif
			},

			// 收藏设计
			async collectDesign() {
				// 检查是否有historyId
				console.log('检查收藏条件 - generatedHistoryId:', this.generatedHistoryId)
				console.log('检查收藏条件 - generatedResult:', this.generatedResult)
				console.log('historyId 类型:', typeof this.generatedHistoryId)

				if (!this.generatedHistoryId) {
					uni.showModal({
						title: '无法收藏',
						content: '由于生成图片时记录保存失败，无法收藏此设计。请使用"保存图片"功能将图片保存到本地。',
						showCancel: false
					})
					return
				}

				// 检查是否正在保存记录
				if (this.isSavingRecord) {
					uni.showToast({
						title: '正在保存记录,请稍候...',
						icon: 'none',
						duration: 2000
					})
					return
				}

				this.isCollecting = true

				try {
					console.log('开始收藏设计，historyId:', this.generatedHistoryId)
					console.log('完整的收藏URL:', `https://fashionai.top/design-collection/collect/${this.generatedHistoryId}`)

					// 发送POST请求到收藏接口
					const result = await post(
						`https://fashionai.top/design-collection/collect/${this.generatedHistoryId}`)

					console.log('收藏结果:', result)
					console.log('收藏结果 code:', result?.code)
					console.log('收藏结果 message:', result?.message)

					// 检查收藏结果
					if (result && result.code === "0") {
						uni.showToast({
							title: '收藏成功',
							icon: 'success'
						})
					} else if (result && result.code === "A000302") {
						// 特殊处理：无法查询到历史记录
						throw new Error('历史记录不存在或已被删除，无法收藏')
					} else {
						throw new Error(result ? result.message : '收藏失败')
					}

				} catch (error) {
					console.error('收藏失败:', error)
					uni.showToast({
						title: '收藏失败: ' + (error.message || '请重试'),
						icon: 'error'
					})
				} finally {
					this.isCollecting = false
				}
			},

			// 重新生成
			retryGenerate() {
				this.generatedResult = null
				this.generatedHistoryId = null // 清空historyId
				this.generateDesign()
			},

		// 刷新页面
			refreshPage() {
				// 清除定时器
				if (this.recordSaveTimer) {
					clearTimeout(this.recordSaveTimer)
					this.recordSaveTimer = null
				}

				// 重置所有页面状态到初始状态
				this.designDescription = ''
				this.selectedBrand = 'ralph-lauren'
				this.generatedResult = null
				this.generatedHistoryId = null
				this.isGenerating = false
				this.isCollecting = false
				this.isSavingRecord = false

				uni.showToast({
					title: '页面已刷新',
					icon: 'success'
				})

				console.log('页面已重置到初始状态')
			}
		}
	}
</script>

<style scoped>
	/* 页面容器 */
	.page-container {
		background-color: #FFF8F0;
		/* 与收藏页面统一的浅米色背景 */
		min-height: 100vh;
	}

	/* 内容包装器 - 为导航栏留出空间 */
	.content-wrapper {
		padding-top: 200rpx;
		/* 为自定义导航栏留出空间，与收藏页面保持一致 */
		padding-bottom: 60px;
		padding-left: 30rpx;
		padding-right: 30rpx;
	}

	/* 模块标题栏（服装设计） */
	.section-header {
		margin: 20rpx 0 40rpx 0;
		display: flex;
		justify-content: space-between;
		align-items: center;
	}

	.title-left {
		display: flex;
		align-items: center;
		gap: 16rpx;
	}

	.title-right {
		padding: 8rpx;
		border-radius: 8rpx;
		transition: all 0.3s ease;
	}

	.title-right:active {
		background-color: rgba(30, 58, 138, 0.1);
	}

	.refresh-icon {
		width: 36rpx;
		height: 36rpx;
		/* 将图标颜色转换为深蓝色 */
		filter: brightness(0) saturate(100%) invert(9%) sepia(39%) saturate(3894%) hue-rotate(227deg) brightness(99%) contrast(96%);
	}

	.header-icon {
		font-size: 36rpx;
		color: #1E3A8A;
	}

	.header-text {
		font-size: 36rpx;
		font-weight: bold;
		color: #1E3A8A;
	}

	/* 橙色铅笔图标 - 纯橙色滤镜 */
	.orange-pencil {
		filter: hue-rotate(0deg) saturate(100%) brightness(1.2);
		color: #FF7F50;
	}

	/* 设计容器 - 统一样式 */
	.design-container {
		background-color: #fff;
		border-radius: 16rpx;
		margin-bottom: 30rpx;
		overflow: hidden;
		box-shadow: 0 2rpx 8rpx rgba(0, 0, 0, 0.06);
	}

	/* 容器标题 - 使用CSS渐变背景 */
	.container-title {
		color: #fff;
		padding: 20rpx 30rpx;
		display: flex;
		align-items: center;
		gap: 16rpx;
	}

	/* 渐变背景1 - 深蓝到浅紫（偏紫） */
	.gradient-1 {
		background: linear-gradient(to right, #1A237E 0%, #4A235A 50%, #9C27B0 100%);
	}

	/* 渐变背景2 - 纯蓝色系（偏蓝） */
	.gradient-2 {
		background: linear-gradient(to right, #00008B 0%, #0064C8 50%, #64B4FF 100%);
	}

	.title-icon {
		width: 32rpx;
		height: 32rpx;
		flex-shrink: 0; /* 防止图标被拉伸 */
	}

	/* 标题栏图标颜色 */
	.section-header .title-icon {
		filter: brightness(0) saturate(100%) invert(9%) sepia(39%) saturate(3894%) hue-rotate(227deg) brightness(99%) contrast(96%);
		/* 这个滤镜会将颜色转换为 #1E3A8A 深蓝色 */
	}

	.title-text {
		font-size: 32rpx;
		font-weight: 500;
	}

	/* 容器内容 */
	.container-content {
		padding: 30rpx;
	}

	/* AI生成提示 */
	.ai-notice {
		margin-bottom: 20rpx;
	}

	.ai-notice-content {
		display: flex;
		align-items: center;
		gap: 8rpx;
	}

	.ai-notice-icon {
		width: 24rpx;
		height: 24rpx;
	}

	.ai-notice-text {
		font-size: 24rpx;
		color: #999999;
	}

	/* 设计描述输入框 */
	.desc-input {
		width: 100%;
		border: 2rpx solid #eee;
		border-radius: 12rpx;
		padding: 24rpx 30rpx;
		min-height: 160rpx;
		box-sizing: border-box;
		font-size: 28rpx;
		background-color: #fafafa;
		margin-bottom: 30rpx;
	}

	.placeholder-text {
		color: #999999;
		font-size: 28rpx;
	}

	/* 品牌选择区域 */
	.brand-section {
		margin-top: 20rpx;
	}

	.brand-hint {
		font-size: 36rpx;
		color: #333;
		margin-bottom: 20rpx;
		display: block;
		font-weight: bold;
	}

	.brand-list {
		display: flex;
		flex-wrap: wrap;
		gap: 20rpx;
	}

	.brand-item {
		border: 2rpx solid #5B9BD5;
		border-radius: 12rpx;
		padding: 20rpx 12rpx;
		display: flex;
		flex-direction: column;
		align-items: center;
		gap: 8rpx;
		width: calc(20% - 16rpx);
		box-sizing: border-box;
		background-color: #fff;
		transition: background-color 0.2s ease, border-color 0.2s ease, transform 0.1s ease;
		/* 只对背景色、边框颜色和变换添加过渡，避免影响其他属性 */
		position: relative;
		/* 添加相对定位，防止内容跳动 */
		overflow: hidden;
		/* 防止内容溢出 */
		-webkit-backface-visibility: hidden;
		/* 优化 WebKit 渲染性能 */
		backface-visibility: hidden;
		/* 优化渲染性能 */
	}

	.brand-item.active {
		border-color: #1E3A8A;
		background-color: #F0F4FF;
	}

	/* 为所有品牌项添加伪元素作为遮罩层，防止白色闪烁 */
	.brand-item::before {
		content: '';
		position: absolute;
		top: 0;
		left: 0;
		right: 0;
		bottom: 0;
		background-color: inherit;
		/* 继承父元素的背景色 */
		z-index: 0;
		/* 确保在内容下方 */
		pointer-events: none;
		/* 不影响点击事件 */
	}

	.item-icon {
		width: 32rpx;
		height: 32rpx;
		position: relative;
		/* 添加相对定位确保图标在遮罩层上方 */
		z-index: 1;
		/* 将图标颜色转换为深蓝色 */
		filter: brightness(0) saturate(100%) invert(9%) sepia(39%) saturate(3894%) hue-rotate(227deg) brightness(99%) contrast(96%);
		/* 添加 will-change 优化滤镜渲染性能 */
		will-change: filter;
	}

	.item-name {
		font-size: 24rpx;
		text-align: center;
		color: #333;
		position: relative;
		/* 添加相对定位确保文字在遮罩层上方 */
		z-index: 1;
	}

	/* 生成按钮 */
	.generate-btn {
		width: 100%;
		margin: 30rpx 0;
		background: linear-gradient(135deg, #1E3A8A 0%, #3B82F6 50%, #5B9BD5 100%);
		color: #fff;
		border-radius: 30rpx;
		padding: 24rpx;
		font-size: 32rpx;
		border: none;
		display: flex;
		align-items: center;
		justify-content: center;
		gap: 12rpx;
		font-weight: bold;
		box-shadow: 0 4rpx 12rpx rgba(30, 58, 138, 0.3);
	}

	/* 生成按钮 - 图片图标样式 */
	.btn-icon-img {
		width: 32rpx;
		height: 32rpx;
		flex-shrink: 0;
		/* 防止图标被压缩 */
		/* 将图标颜色转换为白色 */
		filter: brightness(0) saturate(100%) invert(100%);
	}

	/* 生成按钮 - emoji 图标样式 */
	.btn-icon-emoji {
		font-size: 28rpx;
		line-height: 1;
		/* 移除额外的行高，确保垂直居中 */
		display: inline-flex;
		align-items: center;
		justify-content: center;
	}

	.btn-text {
		font-size: 32rpx;
		line-height: 1;
		/* 移除额外的行高，确保与图标对齐 */
		display: inline-flex;
		align-items: center;
	}

	/* 生成结果占位符 */
	.result-placeholder {
		border: 2rpx dashed #5B9BD5;
		border-radius: 12rpx;
		min-height: 180rpx;
		background-color: #fff;
		display: flex;
		align-items: center;
		justify-content: center;
		padding: 30rpx;
	}

	.placeholder-image {
		width: 150px;
		height: 150px;
		background: linear-gradient(135deg, #F0F4FF, #E6EEFF);
		/* 浅蓝紫色渐变 */
		border-radius: 12rpx;
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		position: relative;
		overflow: hidden;
	}

	.clothing-icon {
		width: 32px;
		height: 32px;
		margin-bottom: 6px;
		display: flex;
		align-items: center;
		justify-content: center;
	}

	.clothing-icon image {
		width: 100%;
		height: 100%;
		filter: grayscale(100%);
	}

	.placeholder-text {
		color: #888888;
		font-size: 12px;
		font-weight: normal;
		text-align: center;
		position: relative;
		z-index: 2;
		max-width: 80%;
	}

	/* 光影扫描效果 - 左下到右上 */
	.shimmer-effect {
		position: absolute;
		top: -50%;
		left: -50%;
		width: 200%;
		height: 200%;
		background: linear-gradient(
			135deg,
			transparent 40%,
			rgba(91, 155, 213, 0.15) 50%,
			transparent 60%
		);
		animation: shimmer 2.5s ease-in-out infinite;
		z-index: 1;
	}

	/* 光影扫描动画 */
	@keyframes shimmer {
		0% {
			transform: translate(0, 0) rotate(0deg);
			opacity: 0;
		}

		50% {
			opacity: 1;
		}

		100% {
			transform: translate(30%, 30%) rotate(45deg);
			opacity: 0;
		}
	}

	/* 生成结果图片容器 */
	.result-image-container {
		display: flex;
		flex-direction: column;
		gap: 20rpx;
	}

	.result-image {
		width: 100%;
		min-height: 300rpx;
		border-radius: 12rpx;
		border: 2rpx dashed #5B9BD5;
		background-color: #fff;
	}

	.result-actions {
		display: flex;
		gap: 20rpx;
	}

	/* 统一按钮样式 - 蓝紫色渐变背景、白色文字 */
	.action-btn {
		flex: 1;
		height: 80rpx;
		border-radius: 12rpx;
		border: none;
		background: linear-gradient(135deg, #1E3A8A 0%, #3B82F6 50%, #5B9BD5 100%);
		font-size: 32rpx;
		color: #fff;
		display: flex;
		align-items: center;
		justify-content: center;
		gap: 12rpx;
		font-weight: 500;
		transition: all 0.3s ease;
		box-shadow: 0 2rpx 8rpx rgba(30, 58, 138, 0.2);
	}

	/* 收藏按钮样式 */
	.collect-btn {
		width: 100%;
		height: 80rpx;
		border-radius: 12rpx;
		border: none;
		background: linear-gradient(135deg, #1E3A8A 0%, #3B82F6 50%, #5B9BD5 100%);
		color: #fff;
		font-size: 32rpx;
		display: flex;
		align-items: center;
		justify-content: center;
		gap: 12rpx;
		margin-top: 8rpx;
		font-weight: 500;
		transition: all 0.3s ease;
		box-shadow: 0 2rpx 8rpx rgba(30, 58, 138, 0.2);
	}

	/* 收藏按钮 - 图片图标样式 */
	.collect-icon-img {
		width: 28rpx;
		height: 28rpx;
		flex-shrink: 0;
		/* 防止图标被压缩 */
		/* 将图标颜色转换为白色 */
		filter: brightness(0) saturate(100%) invert(100%);
	}

	/* 收藏按钮 - emoji 图标样式 */
	.collect-icon-emoji {
		font-size: 24rpx;
		line-height: 1;
		/* 移除额外的行高，确保垂直居中 */
		display: inline-flex;
		align-items: center;
		justify-content: center;
	}

	.collect-text {
		font-size: 28rpx;
		line-height: 1;
		/* 移除额外的行高，确保与图标对齐 */
		display: inline-flex;
		align-items: center;
	}

	/* 警告提示文字样式 */
	.warning-text {
		text-align: left;
		margin-top: 16rpx;
	}

	.warning-text text {
		font-size: 24rpx;
		color: #999999;
	}

	/* 错误提示样式 */
	.error-hint {
		color: #FF6B6B !important;
		font-weight: 500;
	}

	.action-icon {
		width: 28rpx;
		height: 28rpx;
		/* 将图标颜色转换为白色 */
		filter: brightness(0) saturate(100%) invert(100%);
	}

	.action-text {
		font-size: 28rpx;
	}

	/* 按钮悬停效果 */
	.action-btn:active {
		opacity: 0.8;
	}

	.collect-btn:active {
		opacity: 0.8;
	}

	/* 生成按钮禁用状态 */
	.generate-btn:disabled {
		background: #cccccc;
		box-shadow: none;
	}

	/* 收藏按钮禁用状态 */
	.collect-btn:disabled {
		background: #cccccc;
		color: #999999;
	}

	/* 品牌项激活状态优化 */
	.brand-item:active {
		transform: scale(0.95);
		/* 添加缩放效果，而不是改变背景色，避免闪烁 */
	}
</style>